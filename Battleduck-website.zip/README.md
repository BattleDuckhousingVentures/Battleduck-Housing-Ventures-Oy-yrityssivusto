# Battleduck Housing Ventures Oy – Yrityssivusto

React + TailwindCSS -pohjainen yksinkertainen yrityssivu asuntoflippaukseen erikoistuneelle yhtiölle.

## Käyttö

1. Asenna riippuvuudet:
   npm install

2. Käynnistä kehityspalvelin:
   npm run dev

3. Julkaise Netlifyyn tai Verceliin

## Yhteystiedot

Battleduck Housing Ventures Oy  
Harustie 1 E 50, 00980 Helsinki  
Y-tunnus: 3536284-5  
Toimitusjohtaja: Ville Hänninen
